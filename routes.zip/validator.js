function checkNewstitle(value)
    {
        return RegExp().test(value)
    }

function checkContactusqemail(value)
    {
        return RegExp().test(value)
    }

module.exports = {
    checkNewstitle, checkContactusqemail
}