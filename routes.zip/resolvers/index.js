const { Newses, News, AddNews } = require("./news")

const Root = {
    newses: Newses,
    news: News,
    addNews: AddNews
}

module.exports = Root;