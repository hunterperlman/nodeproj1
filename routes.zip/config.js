const Config = {
    SECRET_KEY : "secret key is this"
}

module.exports = Config